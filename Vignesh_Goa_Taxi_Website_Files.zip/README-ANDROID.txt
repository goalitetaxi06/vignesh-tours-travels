CABS GOA VIGNESH — WEBSITE PACKAGE
1. Extract this ZIP on your phone.
2. Open your GitHub repository: https://github.com/goalitetaxi06/vignesh-tours-travels
3. Keep a backup of the current website before replacing files.
4. Upload all files and folders from this package into the repository root (not the ZIP itself).
5. Ensure index.html is in the root. Keep assets as a folder with style.css, main.js and taxi-photo.jpg inside.
6. GitHub repository → Settings → Pages. Keep deployment from branch main and folder / (root).
7. Wait for deployment, then open the live URL in a private/incognito browser tab.
IMPORTANT BEFORE PUBLIC LAUNCH:
- Replace YOUR-DOMAIN in canonical URL, robots.txt and sitemap.xml only after buying/configuring a domain. Until then remove the canonical tag or set the correct GitHub Pages URL.
- Current hero photo is a temporary existing taxi photo. Replace assets/taxi-photo.jpg with a clear, real fleet photo when ready.
- Fleet vehicle photos are intentionally marked PHOTO TO BE ADDED; no stock photos or fake vehicle claims are used.
- Add exact fares only after you confirm the rate card. No prices are invented in this build.
- Confirm exact vehicle seating/capacity and luggage limits before publishing those details.
- Verify the Google Maps pin and business address.
- Add genuine customer reviews only with permission. No sample/fake reviews are included.
- Privacy and booking terms are starter drafts; review and customise them before launch.
- Google Analytics and Search Console are not connected yet.
- Test WhatsApp booking form, phone links, mobile menu, and all pages on your phone before announcing the new site.
- Do not change Google Business Profile name or website URL until you intentionally approve and complete that separate change.
